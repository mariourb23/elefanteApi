import pygraphviz as pgv

personas = [
    {"Nombre": "Persona 1", "Dpi": "123456", "Rol": 1, "Parent": None},
    {"Nombre": "Persona 10", "Dpi": "10", "Rol": 1, "Parent": None},
    {"Nombre": "Persona 2", "Dpi": "234567", "Rol": 2, "Parent": "123456"},
    {"Nombre": "Persona 3", "Dpi": "345678", "Rol": 2, "Parent": "123456"},
    {"Nombre": "Persona 11", "Dpi": "11", "Rol": 2, "Parent": "10"},
    {"Nombre": "Persona 12", "Dpi": "12", "Rol": 2, "Parent": "10"},
    {"Nombre": "Persona 4", "Dpi": "456789", "Rol": 3, "Parent": "12"},
    {"Nombre": "Persona 5", "Dpi": "567890", "Rol": 3, "Parent": "12"},
    {"Nombre": "Persona 6", "Dpi": "678901", "Rol": 3, "Parent": "11"},
    {"Nombre": "Persona 7", "Dpi": "789012", "Rol": 3, "Parent": "345678"},
    {"Nombre": "Persona 8", "Dpi": "890123", "Rol": 4, "Parent": "789012"},
    {"Nombre": "Persona 9", "Dpi": "901234", "Rol": 4, "Parent": "678901"}
    
]

# Mapa de roles
roles = {
    1: "Director Nacional",
    2: "Director Regional",
    3: "Coordinador departamental",
    4: "Coordinador Municipal",
    
}

# Creamos el grafo dirigido
G = pgv.AGraph(strict=True, directed=True)

# Agregamos los nodos y aristas al grafo
for persona in personas:
    nombre = persona["Nombre"]
    dpi = persona["Dpi"]
    rol = roles[persona["Rol"]]
    parent_dpi = persona["Parent"]

    G.add_node(dpi, label=f"{nombre}\nRol: {rol}", shape="box", style="filled", fillcolor="yellow")

    if parent_dpi:
        parent_data = next(filter(lambda x: x["Dpi"] == parent_dpi, personas))
        parent_name = parent_data["Nombre"]
        G.add_edge(parent_dpi, dpi)

# Generamos la imagen del organigrama
G.layout(prog="dot")
G.draw("organigrama.png")

print("Organigrama generado con éxito.")
