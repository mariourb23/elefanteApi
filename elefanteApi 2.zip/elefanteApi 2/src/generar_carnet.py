import pdfkit
import jinja2
from datetime import datetime

class GenerarCarnet:
    def __init__(self):
        # Puedes inicializar cualquier configuración necesaria aquí
        pass

    def generar_carnet(self, nombre, direccion, rol,dpi):
        # Aquí puedes implementar la lógica para generar el carnet
        # Puedes usar bibliotecas de generación de imágenes como PIL para crear el carnet
        print(f"Generando carnet para {nombre} con dirección {direccion} y rol {rol}")
        context = {
            "nombre": nombre,
            "direccion": direccion,
            "rol": rol,
            "dpi": dpi,
            "fecha": datetime.now().strftime("%d/%m/%Y")
        }
        templateLoader = jinja2.FileSystemLoader(searchpath='./')
        template_env = jinja2.Environment(loader=templateLoader)
        html_template = 'carnet.html'
        template = template_env.get_template(html_template)
        output = template.render(context)
        config = pdfkit.configuration(wkhtmltopdf='/usr/local/bin/wkhtmltopdf')
        output_pdf = f"fcarnet_{dpi}.pdf"
        pdfkit.from_string(output, output_pdf, configuration=config)
        