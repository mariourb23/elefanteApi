from flask import Flask, jsonify, request, render_template, url_for, session, redirect, Response, send_from_directory
from config import config
from flask_mysqldb import MySQL
from flask_cors import CORS
from generar_carnet import GenerarCarnet
import requests
import MySQLdb.cursors
import os
import sys

os.environ['DYLD_LIBRARY_PATH'] = '/usr/local/opt/mysql/lib/'


app = Flask(__name__, template_folder='template')

conexion = MySQL(app)
CORS(app) 

#@app.route('/')
#def home():
#    return render_template('index.html')   

@app.route('/admin')
def admin():
    datos = dict(session)
    return render_template('admin.html',datos=datos)   

@app.route('/admin2')
def admin2():
    datos = dict(session)
    return render_template('admin2.html',datos=datos) 

@app.route('/password')
def password():
    return render_template('password.html',dpi=request.args.get('dpi'))

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html',rol=request.args.get('rol'))

@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/logo.png')
def get_logo():
    return send_from_directory(os.path.join(app.root_path, 'static'), 'logo.png')

@app.route('/table')
def table():
    return render_template('table.html',rol=request.args.get('rol'))

@app.route('/graph')
def graph():
    return render_template('graph.html')


@app.route('/login', methods = ['POST'])
def login_validation():
    data = request.json
    print(data)
    if data is not None:
        if 'dpi' in data and 'password' in data:
            _correo = data['dpi']
            _password = data['password']
            
            try:
                cur = conexion.connection.cursor()
                cur.execute('SELECT * FROM Afiliados WHERE DPI = %s AND Password = %s AND Rol IS NOT NULL', (_correo, _password,))
                account = cur.fetchone()
                if account:
                    dic = (('nombre', account[0]), ('dpi', account[1]), ('Rol', account[10]), ('firstLogin', account[12]))
                    accountdic = dict((x, y) for x, y in dic)

                    session['logueado'] = True
                    session['dpi'] = accountdic['dpi']
                    session['rol'] = accountdic['Rol']
                    print (session['rol'])
                    if accountdic['firstLogin'] == 1:
                        return redirect(url_for('password',dpi=session['dpi'],rol=session['rol']))
                    else:
                            return redirect(url_for('dashboard'))

                else:
                    return jsonify({'error': 'DPI ó Contraseña Incorrectas'}), 401

            except Exception as e:
                # Manejar la excepción, por ejemplo, imprimir el mensaje de error
                print(f"Error al ejecutar la consulta SQL: {str(e)}", file=sys.stderr)
                return jsonify({'error': 'Ocurrió un error al procesar la solicitud'}), 500


        else:   
            return jsonify({'error': 'Datos Incorrectos'}), 400
    else:
        return jsonify({'error': 'Los datos JSON no están presentes en la solicitud'}), 400



@app.route('/logout')
def logout():
    session.pop('logueado', None)
    session.pop('id', None)
    session.pop('id_rol', None)
    return redirect(url_for('home'))

@app.route('/users', methods=['GET', 'POST'])
def users():
    if 'loggedin' in session:
        cursor = conexion.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM user')
        users = cursor.fetchall()
        return render_template("users.html", users = users)
    return redirect(url_for('login'))

@app.route('/view', methods=['GET', 'POST'])
def view():
    if 'loggedin' in session:
        viewUserId = request.args.get('userid')
        cursor = conexion.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM user WHERE userid = % s', (viewUserId, ))
        user = cursor.fetchone()
        return render_template("view.html", user = user)
    return redirect(url_for('login'))

#    API   #
@app.route('/votantes', methods=['GET'])
def listar_votantes():
    try:
        cursor = conexion.connection.cursor()
        sql='SELECT * FROM Afiliados'
        cursor.execute(sql)
        votantes = cursor.fetchall()
        personas=[]
        for fila in votantes:
            votante={
                'Nombre':fila[0],
                'Dpi':fila[1],
                'Departamento':fila[2],
                'Direccion':fila[3],
                'Telefono':fila[4],
                'Transporte':fila[5],
                'Empadronamiento':fila[6],
                'CentroDeVotacion':fila[7],
                'Foto':fila[8],
                'Carnet':fila[9],
                'Rol':fila[10]
            }
            personas.append(votante)
        print(votantes)
        return jsonify({'votantes':personas})
    except Exception as ex:
        return jsonify({'Error': "Error cargando Votantes" })
    
@app.route('/listaRoles', methods=['GET'])
def listar_porRoles():
    try:
        cursor = conexion.connection.cursor()
        sql='SELECT Nombre,Dpi, Rol,Parent FROM Afiliados '
        cursor.execute(sql)
        votantes = cursor.fetchall()
        personas=[]
        for fila in votantes:
            votante={
                'Dpi':fila[1], 
                'Nombre':fila[0],
                'Rol':fila[2],
                'dpiPadre':fila[3]
            }
            personas.append(votante)
        print(votantes)
        return jsonify(personas)
    except Exception as ex:
        return jsonify({'Error': "Error cargando Votantes" })

@app.route('/form', methods=['GET'])
def form():
        roles = ['Dirigencia Nacional', ' Director Nacional', 'Director Regional', 'Coordinador Departamental', 'Coordinador Municipal', 'Lider de Comunidad', 'Jefe de Comunidad', 'Promotor', 'Afiliado del elefante']
        rolesfiltered = roles[int(session['rol']):9]
        print(session['rol'])
        return render_template('form.html', roles=rolesfiltered)


@app.route('/conteo', methods=['GET'])
def conteo_afiliados():
    try:
        cursor = conexion.connection.cursor()
        sql='SELECT COUNT(*) FROM Afiliados;'
        cursor.execute(sql)

        return jsonify(cursor.fetchall())
    except Exception as ex:
        return jsonify({'Error': "Error cargando Votantes" })

@app.route('/votantes/<dpi>', methods=['GET'])
def buscar_votante(dpi):
    try:
        cursor = conexion.connection.cursor()
        sql= "SELECT * FROM Afiliados WHERE DPI = '{0}'".format(dpi)
        cursor.execute(sql)
        votante = cursor.fetchone()
        if votante != None:
            persona={
                'Nombre':votante[0],
                'Dpi':votante[1],
                'Carnet':votante[9],
                'Rol':votante[10]
            }
            return jsonify({'votante':persona})
        else:
            return jsonify({'Error': "Votante no encontrado" })
    except Exception as ex:
        return jsonify({'Error': "Error cargando Votante" })
    
@app.route('/votantes', methods=['POST'])
def agregar_votante():
    try:
        cursor = conexion.connection.cursor()
        sql= "SELECT * FROM Afiliados WHERE DPI = '{0}'".format(request.json['Dpi'])
        cursor.execute(sql)
        votante = cursor.fetchone()
        
        if votante != None:
            return jsonify({'Error': "Dpi ya registrado" }), 409
        
        else:
            generador = GenerarCarnet()
            cursor = conexion.connection.cursor()
            sql =  """INSERT INTO Afiliados (Nombre, DPI, Departamento, Direccion, Telefono, Transporte, Empadronamiento, CentroDeVotacion, Foto, Carnet, Rol,Password) 
            values ('{0}', {1}, '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}')""".format(request.json['Nombre'], request.json['Dpi'], request.json['Departamento'], request.json['Direccion'], request.json['Telefono'], request.json['Transporte'], request.json['Empadronamiento'], request.json['CentroDeVotacion'], request.json['Foto'], request.json['Carnet'], request.json['Rol'],request.json['Password'])
            cursor.execute(sql)
            conexion.connection.commit()
            generador.generar_carnet(request.json['Nombre'], request.json['Direccion'], request.json['Rol'], request.json['Dpi'])
            return jsonify({'Mensaje': "Votante registrado" })
    except Exception as ex:
        return jsonify({'Error': "Error cargando Votante" })
    
@app.route('/votantes/<dpi>', methods=['DELETE'])
def eliminar_votante(dpi):
    try:
        cursor = conexion.connection.cursor()
        sql= "DELETE FROM Afiliados WHERE DPI = '{0}'".format(dpi)
        cursor.execute(sql)
        conexion.connection.commit()
        return jsonify({'Mensaje': "Votante eliminado" })
    except Exception as ex:
        return jsonify({'Error': "Error eliminando Votante" })
    
    
@app.route('/votantes/<dpi>', methods=['PUT'])
def actualizar_votante(dpi):
    try:
        cursor = conexion.connection.cursor()
        sql= "SELECT * FROM Afiliados WHERE DPI = '{0}'".format(dpi)
        cursor.execute(sql)
        votante = cursor.fetchone()
        
        if votante != None:
            cursor = conexion.connection.cursor()
            sql =  """UPDATE Afiliados SET Nombre = '{0}', Departamento = '{1}', Direccion = '{2}', Telefono = '{3}', Transporte = '{4}', Empadronamiento = '{5}', CentroDeVotacion = '{6}', Foto = '{7}', Carnet = '{8}', Rol = '{9}' WHERE DPI = '{10}'""".format(request.json['Nombre'], request.json['Departamento'], request.json['Direccion'], request.json['Telefono'], request.json['Transporte'], request.json['Empadronamiento'], request.json['CentroDeVotacion'], request.json['Foto'], request.json['Carnet'], request.json['Rol'], dpi)
            cursor.execute(sql)
            conexion.connection.commit()
            return jsonify({'Mensaje': "Votante actualizado" })
        else:
            return jsonify({'Error': "Votante no encontrado" })
    except Exception as ex:
        return jsonify({'Error': "Error actualizando Votante" })

@app.route('/afiliado/cambio/<dpi>', methods=['PUT'])
def actualizar_contrasena(dpi):
    try:
        cursor = conexion.connection.cursor()
        sql = "SELECT * FROM Afiliados WHERE DPI = %s"
        cursor.execute(sql, (dpi,))
        votante = cursor.fetchone()
        if votante is not None:
            print (votante)
            old_password = request.json.get('OldPassword', None)
            new_password = request.json.get('Password', None)
            print(old_password)
            print(new_password)
            if old_password is not None and new_password is not None:
                if votante[11] == old_password:
                    firstLogin = 0
                    sql = "UPDATE Afiliados SET Password = %s, firstLogin = %s WHERE DPI = %s"
                    cursor.execute(sql, (new_password, firstLogin, dpi))
                    conexion.connection.commit()
                    return jsonify({'Mensaje': "Afiliado ha actualizado su contraseña"})
                else:
                    return jsonify({'Mensaje': "La contraseña anterior no coincide"})
            else:
                return jsonify({'Error': "Se requieren la contraseña anterior y la nueva"})
        else:
            return jsonify({'Error': "Afiliado no encontrado"})
    except Exception as ex:
        return jsonify({'Error': "Error actualizando contraseña"})

@app.route('/verificar/<dpi>', methods=['GET'])
def verificar_dpi(dpi):
    url = 'https://felgttestaws.digifact.com.gt/gt.com.apinuc/api/Shared?TAXID=000075771500&DATA1=SHARED_GETINFOCUI&DATA2=CUI|{0}&COUNTRY=GT&USERNAME=TESTUSER'.format(dpi)
    print(url)
    try:
        headers = {'Authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJVc2VyIjoiR1QuMDAwMDc1NzcxNTAwLlRFU1RVU0VSIiwiQ291bnRyeSI6IkdUIiwiRW52IjoiMCIsIm5iZiI6MTcxMDU0NzEwOCwiZXhwIjoxNzEzMTM5MTA4LCJpYXQiOjE3MTA1NDcxMDgsImlzcyI6Imh0dHBzOi8vd3d3LmRpZ2lmYWN0LmNvbS5ndCIsImF1ZCI6Imh0dHBzOi8vYXBpbnVjLmRpZ2lmYWN0LmNvbS5kby9kby5jb20uYXBpbnVjIn0.JFk6OFA2kXiQgQrbbHXBvdqmE1VlNkFeKtBy83gM5PY'}
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            nombre = data['RESPONSE'][0]['NOMBRE']
            cui = data['RESPONSE'][0]['CUI']
            nombre_procesado = procesar_nombre(nombre)
            respuesta = {'NOMBRE': nombre_procesado, 'CUI': cui}
            return jsonify(respuesta)
        else:
            return jsonify({'Error': "Error consultando API DPI" })
    except Exception as ex:
        return jsonify({'Error': "Error verificando DPI" })

def procesar_nombre(nombre):
    partes = nombre.split(', ')
    partes = partes[::-1]
    nuevo_nombre = ' '.join(partes)
    
    return nuevo_nombre

if __name__ == '__main__':
    app.secret_key = "pinchellave"
    app.config.from_object(config['development'])
    app.run()