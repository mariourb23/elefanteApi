from flask import Flask, jsonify, request, render_template, url_for, session, redirect, Response, send_from_directory
import pdfkit
import requests
import jinja2
import pygraphviz as pgv
import MySQLdb.cursors
from config import config
from flask_mysqldb import MySQL
from flask_cors import CORS
from datetime import datetime
import os
import sys




app = Flask(__name__, template_folder='template')

conexion = MySQL(app)
CORS(app) 

rolesMap = {1:'Dirigencia Nacional', 2:' Director Nacional', 3:'Director Regional', 4:'Coordinador Departamental', 5:'Coordinador Municipal', 6:'Lider de Comunidad', 7:'Jefe de Comunidad', 8:'Promotor', 9:'Amigo del elefante'}

#@app.route('/')
#def home():
#    return render_template('index.html')   

@app.route('/admin')
def admin():
    datos = dict(session)
    return render_template('admin.html',datos=datos)   

@app.route('/admin2')
def admin2():
    datos = dict(session)
    return render_template('admin2.html',datos=datos) 

@app.route('/password')
def password():
    return render_template('password.html',dpi=request.args.get('dpi'))

@app.route('/graph')
def graph():
    return render_template('graph.html')

@app.route('/carnet')
def carnet():
    return render_template('carnet.html')

@app.route('/eliminar')
def eliminar():
    return render_template('eliminar.html',rol=request.args.get('rol'))

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html',rol=request.args.get('rol'))


@app.route('/ingreso')
def login():
    return render_template('login.html')

@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/logo.png')
def get_logo():
    return send_from_directory(os.path.join(app.root_path, 'static'), 'logo.png')

@app.route('/fondo.jpg')
def get_fondo():
    return send_from_directory(os.path.join(app.root_path, 'static'), 'fondo.jpg')

@app.route('/carnet.jpg')
def get_carnetFondo():
    return send_from_directory(os.path.join(app.root_path, 'static'), 'carnet.jpg')


@app.route('/form')
def form():
    rol_value = int(session['rol'])
    print (rol_value)
    if(rol_value <= 2):
        temp = rolesMap
        temp.pop(1, None)
        temp.pop(2, None)
        rolesfiltered = temp
    else:
        rolesfiltered = session['rol']+1
    return render_template('form.html', roles=rolesfiltered)

@app.route('/table')
def table():
    rol_value = int(session['rol'])
    print (rol_value)
    if(rol_value <= 2):
        temp = rolesMap
        temp.pop(1, None)
        temp.pop(2, None)
        rolesfiltered = temp
    else:
        rolesfiltered = session['rol']+1
    return render_template('table.html', roles=rolesfiltered)

@app.route('/login', methods = ['POST'])
def login_validation():
    data = request.json
    print(data)
    if data is not None:
        if 'dpi' in data and 'password' in data:
            _correo = data['dpi']
            _password = data['password']
            
            try:
                cur = conexion.connection.cursor()
                cur.execute('SELECT * FROM Afiliados WHERE DPI = %s AND Password = %s AND Rol IS NOT NULL', (_correo, _password,))
                account = cur.fetchone()

                if account:
                    dic = (('nombre', account[0]), ('dpi', account[1]), ('Rol', account[10]), ('firstLogin', account[12]))
                    accountdic = dict((x, y) for x, y in dic)
                    print('aqui va bien2')
                    print(accountdic)

                    session['logueado'] = True
                    session['dpi'] = accountdic['dpi']
                    session['rol'] = accountdic['Rol']
                    if accountdic['firstLogin'] == 1:
                        return redirect(url_for('password',dpi=session['dpi'],rol=session['rol']))
                    else:
                        return redirect(url_for('dashboard',rol=session['rol']))

                else:
                    return jsonify({'error': 'DPI ó Contraseña Incorrectas'}), 401

                return jsonify(accountdic)   
            except Exception as e:
                # Manejar la excepción, por ejemplo, imprimir el mensaje de error
                print(f"Error al ejecutar la consulta SQL: {str(e)}", file=sys.stderr)
                return jsonify({'error': 'Ocurrió un error al procesar la solicitud'}), 500


        else:   
            return jsonify({'error': 'Datos Incorrectos'}), 400
    else:
        return jsonify({'error': 'Los datos JSON no están presentes en la solicitud'}), 400

@app.route('/ajax/<role>', methods=['GET'])
def ajax(role):
    try:
        rol = int(role)-1
        cursor = conexion.connection.cursor()
        sql= "SELECT Nombre, DPI FROM Afiliados WHERE Rol = '{0}'".format(rol)
        cursor.execute(sql)
        parents = cursor.fetchall()
        possibleOptions = []
        for fila in parents:
            parent={
                'dpi':fila[1],
                'Nombre':fila[0]
            }
            possibleOptions.append(parent)

        # return redirect('hola')
        return jsonify(possibleOptions)
    except Exception as ex:
        print(ex)
        return jsonify({'Error': "Error cargando Votante" })

@app.route('/logout')
def logout():
    session.pop('logueado', None)
    session.pop('id', None)
    session.pop('id_rol', None)
    return redirect(url_for('home'))

@app.route('/users', methods=['GET', 'POST'])
def users():
    if 'loggedin' in session:
        cursor = conexion.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM user')
        users = cursor.fetchall()
        return render_template("users.html", users = users)
    return redirect(url_for('login'))

@app.route('/view', methods=['GET', 'POST'])
def view():
    if 'loggedin' in session:
        viewUserId = request.args.get('userid')
        cursor = conexion.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM user WHERE userid = % s', (viewUserId, ))
        user = cursor.fetchone()
        return render_template("view.html", user = user)
    return redirect(url_for('login'))

#    API   #
@app.route('/votantes', methods=['GET'])
def listar_votantes():
    try:
        cursor = conexion.connection.cursor()
        if session['rol'] <= 2:
            sql="SELECT Nombre,Dpi,Departamento,Direccion,Telefono,Transporte,Empadronamiento,CentroDeVotacion  FROM Afiliados"
        else:
            sql="SELECT Nombre,Dpi,Departamento,Direccion,Telefono,Transporte,Empadronamiento,CentroDeVotacion  FROM Afiliados WHERE Rol >= '{0}'".format(session['rol'])

        cursor.execute(sql)
        votantes = cursor.fetchall()
        personas=[]
        for fila in votantes:
            votante={
                'Nombre':fila[0],
                'Dpi':fila[1],
                'Departamento':fila[2],
                'Direccion':fila[3],
                'Telefono':fila[4],
                'Transporte':fila[5],
                'Empadronamiento':fila[6],
                'CentroDeVotacion':fila[7]
            }
            personas.append(votante)
        return jsonify({'votantes':personas})
    except Exception as ex:
        return jsonify({'Error': "Error cargando Votantes" })
    
@app.route('/listaRoles', methods=['GET'])
def listar_porRoles():
    try:
        cursor = conexion.connection.cursor()
        sql='SELECT Nombre,Dpi, Rol,Parent FROM Afiliados '
        cursor.execute(sql)
        votantes = cursor.fetchall()
        personas=[]
        for fila in votantes:
            votante={
                'Dpi':fila[1], 
                'Nombre':fila[0],
                'Rol':fila[2],
                'dpiPadre':fila[3]
            }
            personas.append(votante)
        return jsonify({"personas":personas})
    except Exception as ex:
        return jsonify({'Error': "Error listando por roles" })

@app.route('/votantes/<dpi>', methods=['GET'])
def buscar_votante(dpi):
    try:
        cursor = conexion.connection.cursor()
        sql= "SELECT * FROM Afiliados WHERE DPI = '{0}'".format(dpi)
        cursor.execute(sql)
        votante = cursor.fetchone()
        if votante != None:
            persona={
                'Nombre':votante[0],
                'Dpi':votante[1],
                'Carnet':votante[9],
                'Rol':votante[10]
            }
            return jsonify({'votante':persona})
        else:
            return jsonify({'Error': "Votante no encontrado" })
    except Exception as ex:
        return jsonify({'Error': "Error cargando Votante" })
    
@app.route('/conteo', methods=['GET'])
def conteo_afiliados():
    try:
        cursor = conexion.connection.cursor()
        sql='SELECT COUNT(*) FROM Afiliados;'
        cursor.execute(sql)

        return jsonify(cursor.fetchall())
    except Exception as ex:
        return jsonify({'Error': "Error cargando Votantes" })
    
@app.route('/votantes', methods=['POST'])
def agregar_votante():
    try:
        cursor = conexion.connection.cursor()
        sql= "SELECT * FROM Afiliados WHERE DPI = '{0}'".format(request.json['Dpi'])
        cursor.execute(sql)
        votante = cursor.fetchone()
        if votante != None:
            return jsonify({'Error': "Dpi ya registrado" }), 409
        else: 
            if int(request.json['Rol']) == session['rol']+1 or session['rol'] <=2 :
                if request.json['Parent'] == None:
                    request.json['Parent'] = session['dpi']
                cursor = conexion.connection.cursor()
                print(request.json)
                sql =  """INSERT INTO Afiliados (Nombre, DPI, Departamento, Direccion, Telefono, Transporte, Empadronamiento, CentroDeVotacion, Foto, Carnet, Rol, Password, firstLogin, Parent,Municipio) 
                values ('{0}', {1}, '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', {10}, '{11}', '{12}', '{13}', '{14}')""".format(request.json['Nombre'], request.json['Dpi'], request.json['Departamento'], request.json['Direccion'], request.json['Telefono'], request.json['Transporte'], request.json['Empadronamiento'], request.json['CentroDeVotacion'], request.json['Foto'], request.json['Carnet'], request.json['Rol'],request.json['Password'], 1, request.json['Parent'],request.json['Municipio'])
                cursor.execute(sql)
                conexion.connection.commit()
                return jsonify({'Mensaje': "Votante registrado" })
            else:
                return jsonify({'Error': "Permiso denegado" }), 302

    except Exception as ex:
        return jsonify({'Error': "Error agregando Votante" }),400
    
@app.route('/votantes/<dpi>', methods=['DELETE'])
def eliminar_votante(dpi):
    try:
        cursor = conexion.connection.cursor()
        sql= "DELETE FROM Afiliados WHERE DPI = '{0}'".format(dpi)
        cursor.execute(sql)
        conexion.connection.commit()
        return jsonify({'Mensaje': "Votante eliminado" })
    except Exception as ex:
        return jsonify({'Error': "Error eliminando Votante" })
    
    
@app.route('/votantes/<dpi>', methods=['PUT'])
def actualizar_votante(dpi):
    try:
        cursor = conexion.connection.cursor()
        sql= "SELECT * FROM Afiliados WHERE DPI = '{0}'".format(dpi)
        cursor.execute(sql)
        votante = cursor.fetchone()
        
        if votante != None:
            cursor = conexion.connection.cursor()
            sql =  """UPDATE Afiliados SET Nombre = '{0}', Departamento = '{1}', Direccion = '{2}', Telefono = '{3}', Transporte = '{4}', Empadronamiento = '{5}', CentroDeVotacion = '{6}', Foto = '{7}', Carnet = '{8}', Rol = '{9}' WHERE DPI = '{10}'""".format(request.json['Nombre'], request.json['Departamento'], request.json['Direccion'], request.json['Telefono'], request.json['Transporte'], request.json['Empadronamiento'], request.json['CentroDeVotacion'], request.json['Foto'], request.json['Carnet'], request.json['Rol'], dpi)
            cursor.execute(sql)
            conexion.connection.commit()
            return jsonify({'Mensaje': "Votante actualizado" })
        else:
            return jsonify({'Error': "Votante no encontrado" })
    except Exception as ex:
        return jsonify({'Error': "Error actualizando Votante" })

@app.route('/afiliado/cambio/<dpi>', methods=['PUT'])
def actualizar_contrasena(dpi):
    try:
        cursor = conexion.connection.cursor()
        sql = "SELECT * FROM Afiliados WHERE DPI = %s"
        cursor.execute(sql, (dpi,))
        votante = cursor.fetchone()
        if votante is not None:
            print (votante)
            old_password = request.json.get('OldPassword', None)
            new_password = request.json.get('Password', None)
            print(old_password)
            print(new_password)
            if old_password is not None and new_password is not None:
                if votante[11] == old_password:
                    firstLogin = 0
                    sql = "UPDATE Afiliados SET Password = %s, firstLogin = %s WHERE DPI = %s"
                    cursor.execute(sql, (new_password, firstLogin, dpi))
                    conexion.connection.commit()
                    return jsonify({'Mensaje': "Afiliado ha actualizado su contraseña"})
                else:
                    return jsonify({'Mensaje': "La contraseña anterior no coincide"})
            else:
                return jsonify({'Error': "Se requieren la contraseña anterior y la nueva"})
        else:
            return jsonify({'Error': "Afiliado no encontrado"})
    except Exception as ex:
        return jsonify({'Error': "Error actualizando contraseña"})

@app.route('/verificar/<dpi>', methods=['GET'])
def verificar_dpi(dpi):
    url = 'https://felgttestaws.digifact.com.gt/gt.com.apinuc/api/Shared?TAXID=000075771500&DATA1=SHARED_GETINFOCUI&DATA2=CUI|{0}&COUNTRY=GT&USERNAME=TESTUSER'.format(dpi)
    print(url)
    try:
        headers = {'Authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJVc2VyIjoiR1QuMDAwMDc1NzcxNTAwLlRFU1RVU0VSIiwiQ291bnRyeSI6IkdUIiwiRW52IjoiMCIsIm5iZiI6MTcxMzIyNTcyNiwiZXhwIjoxNzE1ODE3NzI2LCJpYXQiOjE3MTMyMjU3MjYsImlzcyI6Imh0dHBzOi8vd3d3LmRpZ2lmYWN0LmNvbS5ndCIsImF1ZCI6Imh0dHBzOi8vYXBpbnVjLmRpZ2lmYWN0LmNvbS5kby9kby5jb20uYXBpbnVjIn0.bTTIwQzKiZvpZ6FWt2rqltObbyWoQ0ayM_wjNaPpcPM'}
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            nombre = data['RESPONSE'][0]['NOMBRE']
            cui = data['RESPONSE'][0]['CUI']
            nombre_procesado = procesar_nombre(nombre)
            respuesta = {'NOMBRE': nombre_procesado, 'CUI': cui}
            return jsonify(respuesta)
        else:
            return jsonify({'Error': "Error consultando API DPI" })
    except Exception as ex:
        return jsonify({'Error': "Error verificando DPI" })

@app.route('/organigrama.png', methods=['GET'])
def generar_organigrama():
    endpoint = "http://127.0.0.1:5000/listaRoles"
    response = requests.get(endpoint)
    print(response.status_code)
    
    if response.status_code == 200:
        data = response.json()
        personas = data.get("personas", [])
        print(personas)
    else:
        personas = []

    roles = {
        1: 'Dirigencia Nacional',
        2: 'Director Nacional',
        3: 'Director Regional',
        4: 'Coordinador Departamental',
        5: 'Coordinador Municipal',
        6: 'Lider de Comunidad',
        7: 'Jefe de Comunidad',
        8: 'Promotor',
        9: 'Amigo del elefante'
    }

    G = pgv.AGraph(strict=True, directed=True)
    for persona in personas:
        nombre = persona["Nombre"]
        dpi = persona["Dpi"]
        rol = roles.get(persona["Rol"], "Desconocido")
        parent_dpi = persona["dpiPadre"]

        G.add_node(dpi, label=f"{nombre}\nRol: {rol}", shape="box", style="filled", fillcolor="yellow")

        if parent_dpi:
            parent_data = next(filter(lambda x: x["Dpi"] == parent_dpi, personas), None)
            if parent_data:
                G.add_edge(parent_dpi, dpi)

    G.layout(prog="dot")
    path = os.path.join(app.root_path, 'static')
    
    # Generar la imagen del organigrama y guardarla en el sistema de archivos del cliente
    G.draw("src/static/organigrama.png")

    # Devolver la ruta de la imagen en el sistema de archivos del cliente como una respuesta HTTP
    return send_from_directory(os.path.join(app.root_path, 'static'), 'organigrama.png')


def procesar_nombre(nombre):
    partes = nombre.split(', ')
    partes = partes[::-1]
    nuevo_nombre = ' '.join(partes)
    
    return nuevo_nombre

def generar_carnet(nombre, rol):

        print(f"Generando carnet para {nombre}  y rol {rol}")
        context = {
            "nombre": nombre,
            "rol": rol,
            "fecha": datetime.now().strftime("%d/%m/%Y")
        }
        templateLoader = jinja2.FileSystemLoader(searchpath='./')
        template_env = jinja2.Environment(loader=templateLoader)
        html_template = 'carnet.html'
        template = template_env.get_template(html_template)
        output = template.render(context)
        config = pdfkit.configuration(wkhtmltopdf='/usr/local/bin/wkhtmltopdf')
        output_pdf = f"fcarnet_{dpi}.pdf"
        pdfkit.from_string(output, output_pdf, configuration=config)
    

if __name__ == '__main__':
    app.secret_key = "pinchellave"
    app.config.from_object(config['development'])
    app.run()